package com.dao;

import java.io.Serializable;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;

import com.bean.Employee;
import com.utility.SessionUtility;

public class EmployeeDAO {
	
//	private static SessionUtility sessionUtility;
	private Session session=SessionUtility.getSession();
	
	public int saveEmployee(Employee employee) {
		Transaction transaction = session.beginTransaction();
		int id = (Integer) session.save(employee);
		transaction.commit();
		return id;
	}
	
	public List<Employee> getEmployee() {
		List<Employee> list = session.createQuery("SELECT a FROM Employee a", Employee.class).getResultList();
		return list;
	}
	public Employee getEmployee(int id) {
		Employee employee = session.get(Employee.class, id);
		return employee;
	}
	
	public Employee updateEmployee(int id, Employee employee) {
		employee.setId(id);
		session.clear();
		Transaction transaction = session.beginTransaction();
		session.update(employee);
		transaction.commit();
		Employee employee2 = session.get(Employee.class, id);
		return employee2;
	}
	
	public String deleteEmployee(Employee employee) {
		try {
			Transaction transaction = session.beginTransaction();
			session.delete(employee);
			transaction.commit();
			return "Deleted Successfully";
		} catch (Exception e) {
			e.printStackTrace();
			return "Error Deleting Employee";
		}
	}

}
