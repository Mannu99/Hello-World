package com.main;

import java.util.List;
import java.util.Scanner;

import com.bean.Employee;
import com.dao.EmployeeDAO;

/**
 * Hello world!
 *
 */
public class App {

	private static EmployeeDAO employeeDAO = new EmployeeDAO();

	public static void main(String[] args) {
		System.out.println("Hello World!");

//		Save
		Scanner scanner = new Scanner(System.in);
		while(true) {
			Employee employee=new Employee();
			
			System.out.println("Enter firstName : ");
			String firstName = scanner.nextLine();
			employee.setFirstName(firstName);
			System.out.println("Enter lastName : ");
			String lastName = scanner.nextLine();
			employee.setLastName(lastName);
			System.out.println("Enter contactNumber : ");
			String contactNumber = scanner.nextLine();
			employee.setContactNumber(contactNumber);
			System.out.println("Enter address : ");
			String address = scanner.nextLine();
			employee.setAddress(address);
			System.out.println("Enter designation : ");
			String designation = scanner.nextLine();
			employee.setDesignation(designation);
			System.out.println("Enter salary : ");
			String salary = scanner.nextLine();
			employee.setSalary(salary);
			employeeDAO.saveEmployee(employee);
			System.out.println("Do you want to proceedFurther Y/N ?");
			String proceedFurther = scanner.nextLine();
			if (proceedFurther.equalsIgnoreCase("n")) {
				break;
			}
			
		}
//		Employee employee=new Employee();
//		employee.setFirstName("Himanshu");
//		employee.setLastName("Verma");
//		employee.setContactNumber("9877666866");
//		employee.setAddress("Noida");
//		employee.setSalary("1000000");
//		employee.setDesignation("Software Engineer");
//		int id = employeeDAO.saveEmployee(employee);
//		System.out.println(id);

		System.out.println("______________________All Employees________________________");

//		get
		List<Employee> list = employeeDAO.getEmployee();
		for (Employee employee : list) {
			System.out.println(employee);
		}

		System.out.println("___________________Updated employee___________________________");

//		update
//		Employee employee = new Employee();
//		employee.setFirstName("Himanshu");
//		employee.setLastName("verma");
//		employee.setContactNumber("9877666866");
//		employee.setAddress("banglore");
//		employee.setSalary("1000000");
//		employee.setDesignation(" Senior Software Engineer");
//		Employee updateEmployee = employeeDAO.updateEmployee(34, employee);
//		System.out.println(updateEmployee);
		
//		delete
//		Employee employee = employeeDAO.getEmployee(35);
//		String deleteStatus = employeeDAO.deleteEmployee(employee);
//		System.out.println(deleteStatus);

	}
}
